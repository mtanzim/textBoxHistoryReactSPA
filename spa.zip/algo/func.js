/*
Question 1: Sum to 100
Write a function that, given a string of digits,
build an expression such that the digits will sum to 100 by inserting +, - anywhere between the digits.

For example, given the input 123456789, one such expression is 1 + 23 - 4 + 5 + 6 + 78 - 9 = 100

Your function should return all possible combinations.
*/

function sumToHundred (input) {
  if (typeof(input) !== 'string') throw 'Please supply string of numbers';
  try {
    let number = Number(input);
    if (Number.isNaN(number)) throw 'Not a number';
    // console.log(number);
  } catch (err) {
    throw err || 'Please suppy a string of numbers L2';
  }
  // console.log(input);

  // require a recursive function
  let digitsArr = input.split('');
  let maxLen = digitsArr.length - 1;
  console.log(digitsArr);
  console.log(`maxLen: ${maxLen}`);

  let digitsCombo = [];

  function makeDigitsCombo (curSection, curMaxLen) {
    console.log(`curSection: ${curSection}`);
    let curStr = [];
    let curSectionResult = [];
    let i = 0;
    while (curSection[i] !== undefined && i < curMaxLen) {
    //  while (j < curMaxLen) {
      curStr.push(curSection[i]);
      i ++;
    }
    curSectionResult.push (curStr.join(''));
    return curSectionResult;
  }

  let k = maxLen;
  let j = 0;
  console.log('\n------------------\n')
  while (k > 0) {
    console.log (`K: ${k}`);
    while (j < maxLen) {
      console.log(`j:${j}`);
      console.log(digitsArr.splice(j*k, j*k+k));
      j++;
    }
    k --;
  }


}


/*pseudo code
- Store all permutations of digits combos ie:
input: 123
12,3
1,2,3

reverse and do it again
1,23
1,2,3

Store each line above in an array

Now for each array, try all combinations of +, - ie:
Item: 12,3
Combos:
12+3
12-3

Item: 1,2,3
1+2+3
1-2+3
1+2-3

Now iterate over all combinations, and push the expresssions that add to a 100
Recursive approach is ideal
*/


sumToHundred('123');
// sumToHundred('12312313123ss');
// sumToHundred(1231231312312);